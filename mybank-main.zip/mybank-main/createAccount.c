#include "bwave.h"
/**
 * createAccount - creates account of user
 * Return: void
 */
void createAccount()
{
	char fullName[MAX_LENGTH];

	printf("Please create an account \nEnter your full name here: ");
	fgets(fullName, sizeof(fullName), stdin);

}
