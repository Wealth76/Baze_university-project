#include "bwave.h"
/**
 * checkBalance - checks current balance
 * Return: Nothing
 */

void checkBalance(double balance)
{
	printf("Your current balance is: %.2f \n", balance);
}
